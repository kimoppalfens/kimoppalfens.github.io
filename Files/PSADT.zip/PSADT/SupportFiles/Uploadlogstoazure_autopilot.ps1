Import-Module azure.storage

$BlobProperties = @{

    StorageAccountName   = '<Replace with Storage Account Name>'
    storSas              = '<Replace with SAS Key>'
    container            = '<Replace with Blob container Name>'
}

$TSHostname = $env:computername

$hostname = ($TSHostname).tolower()
$Timestamp = get-date -f yyyy-MM-dd-HH-mm-ss
$localpath = "C:\LogsToAzure\$hostname-$Timestamp"

New-Item -ItemType Directory -Path $localpath -Force
New-Item -ItemType Directory -Path $localpath\Panther -Force
New-Item -ItemType Directory -Path $localpath\Software -Force
New-Item -ItemType Directory -Path $localpath\Dism -Force
New-Item -ItemType Directory -Path $localpath\IME -Force

Get-ChildItem -Path C:\Windows\Panther | Copy-Item -Destination $localpath\Panther -Recurse
Get-ChildItem -Path C:\Windows\Logs\Software | Copy-Item -Destination $localpath\Software -Recurse
Get-ChildItem -Path C:\Windows\Logs\Dism | Copy-Item -Destination $localpath\Dism -Recurse
Get-ChildItem -Path 'C:\ProgramData\Microsoft\IntuneManagementExtension\Logs' | Copy-Item -Destination $localpath\IME -Recurse

write-host "compressing logfiles"
Compress-Archive -Path $localpath -DestinationPath "C:\LogsToAzure\$hostname-$Timestamp.zip"

write-host "Generating symmetric key"
C:\Openssl\x64\bin\openssl rand 100 > "C:\LogsToAzure\symmetric_keyfile.key"

write-host "Encrypt zipfile with symmetric key"
C:\Openssl\x64\bin\openssl enc -in "C:\LogsToAzure\$hostname-$Timestamp.zip" -out "c:\logstoazure\$hostname-$Timestamp.enc" -e -aes-256-cbc -md sha512 -pbkdf2 -iter 100000 -salt -pass file:"C:\LogsToAzure\symmetric_keyfile.key"

write-host "Encrypt symmectric key with public key"
C:\Openssl\x64\bin\openssl rsautl -encrypt -inkey "C:\Openssl\x64\bin\public_key.pem" -pubin -in "C:\LogsToAzure\symmetric_keyfile.key" -out "C:\LogsToAzure\$hostname-$Timestamp.key.enc"

write-host "upload to azure"
$clientContext = New-AzureStorageContext -SasToken ($BlobProperties.storsas) -StorageAccountName ($blobproperties.StorageAccountName)

Set-AzureStorageBlobContent -Context $ClientContext -container ($BlobProperties.container) -File "c:\logstoazure\$hostname-$Timestamp.enc"
Set-AzureStorageBlobContent -Context $ClientContext -container ($BlobProperties.container) -File "C:\LogsToAzure\$hostname-$Timestamp.key.enc"

Unregister-ScheduledTask -TaskName "CopyLogs" -Confirm:$false