Put the following files/folders here :
Azure.Storage (Powershell module)
AzureRM.profile (Powershell module)
OpenSSL (Toolkit for encryption)
VC_RedistX64.exe (VC++ Redistributable)