﻿<#
.SYNOPSIS
	This GUI allows for (basic) easy creation of PsAppDeploymentToolkit packages.
.DESCRIPTION
        - Fully unattended generation of the Deploy-Application.PS1 file
        - Merging of your source binaries with the PS App toolkit on a destination Share (must be UNC)
        - Creating the SCCM Application + Deployment Type
        - Adding a Software ID tag and using this as a detection mechanism.
.NOTES
    FileName:    PSAPP_GUI.ps1
    Blog: 	 http://www.OSCC.Be
    Author:      Tom Degreef
    Twitter:     @TomDegreef
    Email:       Tom.Degreef@OSCC.Be
    Created:     2017-08-23
    Updated:     2017-09-05
    
    Version history
    1.1   - (2017-09-06) Experimental support for SWID-Tag lookup is added
    1.0   - (2017-09-05) Added 2nd Tab for SCCM, Allowing software distribution & Collection Creation
    0.9	  - (2017-08-23) Initial version of the GUI
.LINK 
	Http://www.OSCC.Be
#>

$gui_version = '1.1'
$logfile = "$env:systemdrive\temp\PSAPPgui\PSAPP_Gui.txt"
$logmodule = "$env:systemdrive\temp\PSAPPgui\PSAPP_Gui.log"
$global:packagepath = ""
$global:architecture = ""
$global:fullname=""
$global:Sitecode=""

$logopath = "$psscriptroot\OSCCLogo.jpg"

#Check if OSCC Logging module is installed, if not, install it
if ($PSVersionTable.PSVersion -ge '5.0.0.0')
{
  if (!(Get-PackageProvider | ? {$_.Name -eq 'NuGet'}))
    {  Install-PackageProvider -Name Nuget -force -MinimumVersion 2.8.5.208 }
  if (!(get-module -ListAvailable -Name osccpslogging | ? {$_.Version -ge '1.5.0.1'}))
    { 
    write-host "installing module"
    install-module -Name OSCCPsLogging -MinimumVersion 1.5.0.1 -Force}
}

if (!(test-path "$env:systemdrive\temp\PSAPPgui"))
{
       New-Item -itemtype Directory -path $env:systemdrive\temp\PSAPPgui -Force
}

try {$log = Initialize-CMLogging -LogFileName $logmodule -ConsoleLogLevel off -fileLogLevel info} catch {}
function log-item
{
param(  $logline,
        $severity = "Info" )
      [string]$currentdatetime = get-date
        if (get-module -name OSCCPSLogging)
      {
                Switch ($severity)
                {
                        "Info" {$log.Info($logline)}
                        "Warn" {$log.Warn($logline)}
                        "Error" {$log.Error($logline)}
                }
                
      }
        else
        {
                 Switch ($severity)
                {
                        "Info" {[string]$output = $currentdatetime + " - INFO - " + $logline}
                        "Warn" {[string]$output = $currentdatetime + " - WARNING - " + $logline}
                        "Error" {[string]$output = $currentdatetime + " - ERROR - " + $logline}
                }              
        $output | out-file $Logfile -append
        }
}

Log-Item -logline "Starting Powershell AppDeployment Toolkit GUI version $gui_version"

try 
        {
        $inputXML = Get-Content "$psscriptroot\MainWindow.xaml" -ErrorAction stop
        $inputXML = $inputXML -replace "ReplacePath", $logopath
        log-item("GUI XML sucessfully loaded")
        }
catch 
        {
        log-item -logline "error loading GUI XML" -severity "Error"
        log-item -logline "exiting script" -severity "Error"
        exit        
        }

try {
        $inputApptoolkit = get-content "$psscriptroot\Deploy-Application.ps1" -ErrorAction stop
        log-item("'Powershell AppDeployment Toolkit' input-file succesfully loaded")
}
catch {
        log-item -logline "error loading 'Powershell AppDeployment Toolkit' input-file " -severity "Error"
        log-item -logline "exiting script" -severity "Error"
        exit        
}

function lookup-url
{
        param($url)
        
        [Regex]$regidYY = "[1-2]\d{3}"
        [Regex]$regidMM = "[0-1][0-9]"
        
        $error.clear()
        
        $verify = $url.split(".")
        
        if ($verify[1] -eq "COM" -or $verify[1] -eq "EDU" -or $verify[1] -eq "ORG" -or $verify[1] -eq "NET")
        {
            $web = New-WebServiceProxy ‘http://www.webservicex.net/whois.asmx?WSDL’
            [string]$webresult = $web.GetWhoIs($url)
            if ($error.count -eq 0)
            {
            $creationindex = $webresult.indexof("Creation Date:")
        
            $myyear = $webresult.Substring($creationindex+15,4)
            $mymonth = $webresult.Substring($creationindex+20,2)
        
                if ($myyear -match $regidyy -and $mymonth -match $regidmm)
                    {
                        $wpfregidYY.Text =  $myyear
                        $wpfregidYY.Tag = 'cleared' 
                        $wpfregidMM.Text = $mymonth
                        $wpfregidMM.Tag = 'cleared'
                        $wpfregidDomain.Text = $verify[1] + "." + $verify[0]
                        $wpfregidDomain.Tag = 'cleared'
                        log-item -logline ("Lookup of " + $wpfVendorLookup.text + " succeeded. Pre-filling data in form") 
                    }
                else
                    {
                        [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
                        [Microsoft.VisualBasic.Interaction]::MsgBox("Lookup failed. Please check manually at www.whois.net",'OKOnly,Information',"Ping")
                        log-item -logline ("Lookup failed for " + $wpfVendorLookup.text ) -severity Error
                    }
            }
            else
            {
                [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
                [Microsoft.VisualBasic.Interaction]::MsgBox("Lookup failed. Please check manually at www.whois.net",'OKOnly,Information',"Ping")
                log-item -logline ("Lookup failed for " + $wpfVendorLookup.text ) -severity Error
            }
        }
        else
        {
                [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
                [Microsoft.VisualBasic.Interaction]::MsgBox("Only COM,ORG,NET & EDU are supported",'OKOnly,Information',"Ping")
                log-item -logline ("Only COM,ORG,NET & EDU are supported, provided domain is : " + $wpfVendorLookup.text ) -severity Warn}
        
}                

Function Compose-Package
{
        Param($source,$destination,$appvendor,$appname,$appversion,$appbitness)

        Switch ($appbitness)
                {
                "0"
                        {
                        $global:architecture = "X86"
                        }
                "1"
                        {
                        $global:architecture = "X64"
                        }
                }

        if ($destination.Endswith("\"))
        {
                $global:packagepath = $destination + $appvendor + "\" + $appname + "_" + $appversion + "_" + $global:architecture
        }
        else
        {
                $global:packagepath = $destination + "\" + $appvendor + "\" + $appname + "_" + $appversion + "_" + $global:architecture
        }
        $pct = 0

        new-item -itemtype Directory -path $packagepath -force

        #$WPFPackage_progress.Content = "Copying toolkit to $packagepath"
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFPackage_progress.Content = "Copying toolkit to $packagepath"} ),$null, $null )

        Copy-item -path "$psscriptroot\Toolkit\*" -Destination $packagepath -Recurse -Force
        log-item ("Copying toolkit to $packagepath")

        $sourcefiles = Get-ChildItem $source -Recurse -Force
        
        [float]$blocks = (100 / $sourcefiles.Count)
        foreach ($file in $sourcefiles)
                {
                        $size = "{0:N2}" -f (($file.Length)/1MB)
                        $dest = ($file.FullName -replace [regex]::Escape($source), "$packagepath\Files")

                        #$WPFPackage_progress.Content = "Copying file $file with size $size MB"
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFPackage_progress.Content = "Copying file $file with size $size MB"} ),$null, $null )

                       if ($file.PSIsContainer)
                        {
                                $null = New-Item -ItemType Container -Path $dest -force
                                log-item ("Created folder $dest")
                        }
                        if (-not $file.psiscontainer)
                        {
                                Copy-Item $file.fullname -Force -Destination $dest
                                log-item ("Copying $file ($size MB)")
                        }
                        
                        $pct += $blocks
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{ $wpfprogress.Value = $pct } ),$null, $null )

                }

}

$inputXML = $inputXML -replace 'mc:Ignorable="d"','' -replace "x:N",'N' -replace '^<Win.*', '<Window'
 
[void][System.Reflection.Assembly]::LoadWithPartialName('presentationframework')
[xml]$XAML = $inputXML
#Read XAML
 
    $reader=(New-Object System.Xml.XmlNodeReader $xaml)
  try{$Form=[Windows.Markup.XamlReader]::Load( $reader )}
catch{log-item -logline "Unable to load Windows.Markup.XamlReader. Double-check syntax and ensure .net is installed." -severity "Error"}
 
#===========================================================================
# Load XAML Objects In PowerShell
#===========================================================================
 
$xaml.SelectNodes("//*[@Name]") | %{Set-Variable -Name "WPF$($_.Name)" -Value $Form.FindName($_.Name) -scope global}
 
# Function Get-FormVariables{
# if ($global:ReadmeDisplay -ne $true){Write-host "If you need to reference this display again, run Get-FormVariables" -ForegroundColor Yellow;$global:ReadmeDisplay=$true}
# write-host "Found the following interactable elements from our form" -ForegroundColor Cyan
# get-variable WPF*
# }
#  
# Get-FormVariables


[float]$blocks = (100 / $inputApptoolkit.Count)

[int]$progress = 0
$wpfprogress.Value = $progress
$WPFProgress_SCCM.value = 0

$WPFGenerate.add_Click({
        
#$WPFPackage_progress.Content = "Valdating input ..."
$Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFPackage_progress.Content = "Valdating input ..."} ),$null, $null )

[int]$countpath = 0
        if(test-path $wpfInputSource.text)
        {
                $wpfInputSource.background = "green"
                $countpath += 1
                $writeoutput = $wpfInputSource.text
                Log-Item("$writeoutput is accessible and will be used for the source-binaries")
        }
        else 
        {
                $wpfInputSource.background = "red"
                $writeoutput = $wpfInputSource.text
                Log-Item -logline "$writeoutput is not accessible, script cannot continue" -severity "Error"
        }

        if (test-path $wpfInputDestination.text)
        {
                $wpfInputDestination.background = "green"
                $countpath += 1
                $writeoutput = $wpfInputdestination.text
                Log-Item("$writeoutput is accessible and will be used to copy the full App deployment package to")
        }
        else
        {
                $wpfInputDestination.background = "red"
                $writeoutput = $wpfInputdestination.text
                Log-Item -logline "$writeoutput is not accessible, script cannot continue" -severity "error"
        }

        if ($wpfvendor.text -eq "")
        {
                $wpfvendor.background = "red"
                Log-Item -Logline "Need a Vendor to continue" -Severity "Warn"
        }
        else {
                $wpfvendor.background = "green"
                $countpath += 1
        }

        if ($wpfappname.text -eq "")
        {
                $wpfappname.background = "red"
                Log-Item -Logline "Need an Application Name to continue" -Severity "Warn"
        }
        else {
                $wpfappname.background = "green"
                $countpath += 1
        }

        if ($wpfappversion.text -eq "")
        {
                $wpfappversion.background = "red"
                Log-Item -Logline "Need an Application Version to continue" -Severity "Warn"
        }
        else {
                $wpfappversion.background = "green"
                $countpath += 1
        }

        [Regex]$regidYY = "[1-2]\d{3}"
        [Regex]$regidMM = "[0-1][0-9]"
        [Regex]$regidDomain = "\w{2,}.\w+"
        $currentyear = (Get-Date).year
        
        
        if (!($WPFRegIDYY.text -in 1985..$currentyear))
        {
                $WPFRegIDYY.background = "red"
                Log-Item -Logline "SoftwareID-Tag : Year when domain-name was registered is missing or incorrect (must be between 1985 and $currentyear). Info can be found on www.whois.net" -Severity "Warn"
        }
        else {
                $WPFRegIDYY.background = "green"
                $countpath += 1
        }

        if (!($wpfregIDMM.text -in 1..12 -and $wpfregidMM.text -match $regidMM))
        {
                $wpfregidMM.background = "red"
                Log-Item -Logline "SoftwareID-Tag : Month when domain-name was registered is missing or incorrect (must be in 2-digit format, eg January = 01). Info can be found on www.whois.net" -Severity "Warn"
        }
        else {
                $wpfregidMM.background = "green"
                $countpath += 1
        }

        if (!($wpfregidDomain.text.toupper() -match $regidDomain))
        {
                $wpfregidDomain.background = "red"
                Log-Item -Logline "SoftwareID-Tag : Domain-name is missing." -Severity "Warn"
        }
        else {
                $wpfregidDomain.background = "green"
                $countpath += 1
        }

        if ($WPFLicense.SelectedIndex -eq "-1")
        {
                $wpfLicenseText.background = "red"
                Log-Item -Logline "Select Yes/No for License Requirements" -Severity "Warn"
        }
        else {
                $wpfLicenseText.background = "green"
                $countpath += 1
        }

if ($countpath -eq 9)
{
        $FullRegid = "RegID." + $wpfregidYY.text + "-" + $wpfregidMM.text + "." + $wpfregiddomain.text
        #$WPFPackage_progress.Content = "Copying toolkit files to destination folder ... (This can take a while)"
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFPackage_progress.Content = "Copying toolkit files to destination folder ... (This can take a while)"} ),$null, $null )
        
        Compose-Package -source $wpfinputsource.text -destination $wpfInputDestination.text -appvendor $wpfvendor.text -appname $wpfappname.text -appversion $wpfappversion.text -appbitness $wpfApparchitecture.SelectedIndex

        $output = $global:packagepath + "\Deploy-Application.ps1"
       
        #$wpfpackage_progress.Content = "Generating Deploy-Application.PS1 file ..."
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfpackage_progress.Content = "Generating Deploy-Application.PS1 file ..."} ),$null, $null )
        $writeoutput = "### Generated FILE from GUI with GUIToolkit version $gui_version ###"
        $writeoutput | out-file $output
        for ($i=0; $i -lt  $inputApptoolkit.Count; $i++)
                {
                $defaultline = $false
                $Linefrominput =  $inputApptoolkit[$i].tostring().trim()
                Switch ($Linefrominput)
                        {
                        "<GUIAppVendor>"
                                {
                                        $writeoutput = '	[string]$appVendor = ''' + $wpfvendor.text + "'"
                                }
                        "<GUIAppVendor_WS>"
                                {
                                        $writeoutput = '	[string]$appVendor_WithSpace = ''' + $wpfvendor.text + "'"
                                }   
                        "<GUIAppName>"
                                {
                                        $writeoutput = '	[string]$appName = ''' + $wpfAppname.text + "'"
                                }
                        "<GUIAppName_WS>"
                                {
                                        $writeoutput = '	[string]$appName_WithSpace = ''' + $wpfAppname.text + "'"
                                }
                        "<GUIAppVersion>" 
                                {
                                        $writeoutput = '	[string]$appVersion = ''' + $wpfAppversion.text + "'"
                                }
                        "<GUIAppArch>"
                                {Switch ($wpfApparchitecture.SelectedIndex)
                                {
                                "0"
                                        {$writeoutput = '	[string]$appArch = ''X86'''
                                        }
                                "1"
                                        {$writeoutput = '	[string]$appArch = ''X64'''
                                        }
                                }
                                }
                        "<GUIAppLang>"
                                {$writeoutput = '	[string]$appLang = ''' + $wpfapplanguage.text + "'"
                                }
                        "<GUIAppRevision>"
                                {$writeoutput = '	[string]$appRevision = ''' + $wpfapprevision.text + "'"
                                }
                        "<GUIRegID>"
                                {$writeoutput = '	[string]$appVendorSWIDTAGRegID = ''' + $FullRegid + "'"
                                }
                        "<GUIScriptVersion>"
                        {$Writeoutput = '	[string]$appScriptVersion = ''' + '1.0.0' + "'"
                        }
                        "<GUIAppCreator>"
                        {$username = [Security.Principal.WindowsIdentity]::GetCurrent().Name
                        $Writeoutput = '	[string]$appScriptAuthor = ''' + $username + "'"
                        }
                        "<GUIAppdate>"
                                {$date = get-date -format dd/MM/yyyy 
                                $Writeoutput = '	[string]$appScriptDate = ''' + $date + "'"
                                }
                        "<GUIInstallCmdline>"    
                                {   Switch ($WPFInstallType.SelectedIndex)
                                {
                                "0" 
                                        {
                                        $writeoutput = '		Execute-MSI -Action ''Install'' -path ''' + $wpfinstallpath.Text + "' -Parameters '" +$WPFInstallPath_Parameters.Text + "'"
                                        }
                                "1" 
                                        {
                                        $writeoutput = '		Execute-Process -path ''' + $wpfinstallpath.Text + "' -Parameters '" +$WPFInstallPath_Parameters.Text + "'"
                                        }
                                } 
                                }
                        "<GUIUnInstallCmdline>"
                                { Switch ($WPFInstallType.SelectedIndex)
                                {
                                "0" 
                                        {
                                        $writeoutput = '		Remove-MSIApplications -Name ''' + $WPFUninstallCmd.Text + "'"
                                        }
                                "1"
                                        {
                                        $writeoutput = '		Execute-Process -path ''' + $WPFUninstallCmd.Text + "'"
                                        }
                                }
                                } 
                        "<GUIWriteIDTag>"
                                { 
                                Switch ($WPFLicense.SelectedIndex)
                                        {
                                        "1" { 
                                        $writeoutput =
@"
		## Writes unique file in ProgramData folder
		Write-Log -Message "Create and Write SWIDTag in ProgramData Folder" -Source 'Install' -LogType 'CMTrace'
		Write-SWIDTag -CreatorRegid `$appVendorSWIDTAGRegID -EntitlementRequired `$FALSE
		Invoke-SCCMTask 'HardwareInventory'
"@

                                        }
                                "0"
                                        {
                                        $writeoutput = 
@"
		## Writes unique file in ProgramData folder
		Write-Log -Message "Create and Write SWIDTag in ProgramData Folder" -Source 'Install' -LogType 'CMTrace'
		Write-SWIDTag -CreatorRegid `$appVendorSWIDTAGRegID -EntitlementRequired `$TRUE
		Invoke-SCCMTask 'HardwareInventory'
"@
                                        }
                                
                                }
                        }
                        "<GuiRemoveIDTag>"
                                {
                                        $writeoutput = 
@"
		## Removes unique file from ProgramData folder
		Write-Log -Message "Remove SWIDTAG File" -Source 'UnInstall' -LogType 'CMTrace'
                `$tag = `$env:ProgramData + '\' + `$appVendorSWIDTAGRegID + '\' + `$appVendorSWIDTAGRegID + '_' + `$appName + '_' + `$AppVersion + '_' + `$AppArch +'.swidtag'
		Remove-File -Path `$Tag
		Invoke-SCCMTask 'HardwareInventory'
"@

                                }
                        default 
                                {
                                        $writeoutput = $inputApptoolkit[$i]
                                        $defaultline = $true       
                                }
                        }

                $writeoutput | out-file $output -append
                if ($defaultline -eq $false)
                {log-Item("Adding $writeoutput on line $i")}
                $progress += $blocks
                
                #$wpfprogress.Dispatcher.Invoke("Render", ([Action]{$wpfprogress.Value = $progress}),"Normal",$null )
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{ $wpfprogress.Value = $progress; } ),$null, $null )
              
               
                
                }
                $wpfprogress.Value = 100
                $WPFSCCM.isenabled = $true
                #$wpfsccm.background = "green"
                #$wpfpackage_progress.Content = "Finished creating package on destination location"
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfpackage_progress.Content = "Finished creating package on destination location"} ),$null, $null )
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfsccm.background = "green" } ),$null, $null )
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{ $wpfprogress.Value = $progress } ),$null, $null )
}               
})

$WPFConnect_SCCM.add_click(
        {
                $Connection = $False
                
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfImport_progress.Content = "Connecting to SCCM Environment ..."} ),$null, $null )
                Try
                {
                        Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1" -ErrorAction Stop # Import the ConfigurationManager.psd1 module 
                        $global:Sitecode = (Get-PSDrive -PSProvider CMSite).Name
                        log-item ("SCCM Sitecode = $Sitecode")
                        Set-Location ($global:Sitecode + ":") # Set the current location to be the site code.
                        #$WPFsitecode.Content = "Connected to Site : " + $global:Sitecode
                        $wpfSiteCode.background = "Green"
                        $Connection = $True
                        $WPFImport_SCCM.isenabled = $true
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFsitecode.Content = "Connected to Site : " + $global:Sitecode} ),$null, $null )
                }
                Catch
                {
                        log-item ("Failed connecting to the SCCM Environment") -severity "Error"
                        #$wpfImport_progress.Content = "Failed connecting to the SCCM Environment"
                        $WPFConnect_SCCM.Background="Red"
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFsitecode.Content = "Failed connecting to the SCCM Environment"} ),$null, $null )
                       # $WPFProgress_SCCM.Foreground="Red"
                       # $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{ $WPFProgress_SCCM.value = 100; } ),$null, $null )
                }
                
                if ($connection)
                {
                        
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfImport_progress.Content = "Enumerating Distribution Points"} ),$null, $null )
                        $DPs = get-cmdistributionpoint -allsite
                        foreach ($dp in $dps)
                        {
                                $wpfdp.Items.Add($dp.NetworkOsPath.trimstart("\"))
                        }
                        $DPGs = Get-CMDistributionPointGroup
                        foreach ($dpg in $dpgs)
                        {
                                $wpfdpgroup.items.add($dpg.name)
                        }
                        #$wpfImport_progress.Content = "Distribution Points enumerated from site"
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfImport_progress.Content = "Distribution Points enumerated from site"} ),$null, $null )
                }
        }
)

$WPFImport_SCCM.add_Click(
{

        $Appcreated = $false
        #$wpfImport_progress.Content = "Connected to SCCM Site $Sitecode, starting creation of application... Please wait"
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfImport_progress.Content = "Connected to SCCM Site $Sitecode, starting creation of application... Please wait"} ),$null, $null )
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{ $WPFProgress_SCCM.value = 10 } ),$null, $null )
        $appwithoutspaces = $wpfappname.text -replace " ",""

        $fullregid = "RegID." + $wpfregidYY.text + "-" + $wpfregidMM.text + "." + $wpfregiddomain.text

        $detectionscript = "if (test-path 'C:\ProgramData\" + $fullregid + "\" + $fullregid + "_" + $appwithoutspaces + "_" + $WPFappVersion.text + "_" + $global:architecture +".swidtag') {write-host 'found swidtag'}"
        Log-Item ("Detection mechanism is : ")
        log-item ("$detectionscript")

        if ($wpfappLanguage.text -ne "")
        {
                $global:fullname = $WPFvendor.text + "_" + $wpfappname.text + "_" + $wpfappVersion.text + "_" + $wpfappLanguage.text + "_" + $global:architecture
        }
        else {
                $global:fullname = $WPFvendor.text + "_" + $wpfappname.text + "_" + $wpfappVersion.text + "_" + $global:architecture
        }

        try 
        {
        New-CMApplication -Name $global:fullname -Manufacturer $wpfvendor.text -SoftwareVersion $wpfappversion.text -ErrorAction Stop
        #$wpfImport_progress.Content = "Application Created, adding SCCM Deployment Type... Please wait"
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{ $WPFProgress_SCCM.value = 50 } ),$null, $null )
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfImport_progress.Content = "Application Created, adding SCCM Deployment Type... Please wait"} ),$null, $null )
        log-item ("SCCM Application with name $fullname created")
        $appcreated = $true
        }
        catch
        {
            Log-Item -logline "Caught an exception:" -severity "Error"
            log-item -logline "Exception Type: $($_.Exception.GetType().FullName)" -severity "Error"
            log-item -logline "Exception Message: $($_.Exception.Message)" -severity "Error"
                $wpfpackage_progress.Content = "Failed creating new application"
                $wpfImport_progress.Foreground="Red"
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{ $WPFProgress_SCCM.value = 100; } ),$null, $null )
        }

        if ($Appcreated)
        {
                try
                {
                Add-CMScriptDeploymentType -ApplicationName $global:fullname -ContentLocation $packagepath -DeploymentTypeName $global:fullname -InstallCommand "Deploy-Application.exe -DeploymentType `"Install`"" -UninstallCommand "Deploy-Application.exe -DeploymentType `"UnInstall`"" -Scriptlanguage powerShell -ScriptContent $detectionscript -ErrorAction Stop
                log-item ("Deployment type with name $fullname created")
                #$wpfImport_progress.Content = "Done creating SCCM Application"
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfImport_progress.Content = "Done creating SCCM Application"} ),$null, $null )
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFProgress_SCCM.value = 100 } ),$null, $null )
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$wpfCollname.Content = $global:fullname} ),$null, $null )
                $wpfGenerate_Collections.Isenabled = $true
                $wpfdistribute.isenabled = $true
                }
                catch
                {
                    Log-Item -logline "Caught an exception:" -severity "Error"
                    log-item -logline "Exception Type: $($_.Exception.GetType().FullName)" -severity "Error"
                    log-item -logline "Exception Message: $($_.Exception.Message)" -severity "Error"
                        $wpfImport_progress.Content = "Failed adding deployment type"
                        $WPFProgress_SCCM.Foreground="Red"
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{ $WPFProgress_SCCM.value = 100; } ),$null, $null )
                }

                
        }
})

$wpfdistribute.add_click(
{
        $TotalselectedDP = $wpfdp.selecteditems.count + $wpfdpgroup.selecteditems.count
        Log-item "Total number of selected Dp's and DP groups is : $TotalSelectedDP"

        [float]$DPBlocks = (100 / $TotalselectedDP)
        $dpprogress = 0

        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFdistribute_progress.Content = "Preparing $totalselecteddp distribution(s)"} ),$null, $null )
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFPB_Progress_distribute.Value = 0} ),$null, $null )
        foreach ($DP in $wpfdp.SelectedItems)
        {
                Try 
                {
                Start-CMContentDistribution -ApplicationName $fullname -DistributionPointName $dp -erroraction stop
                log-item -logline "Starting distribution to DP : $dp"
                $dpprogress = $dpprogress + $dpblocks
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFdistribute_progress.Content = "Starting distribution to DP : $dp"} ),$null, $null )
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFPB_Progress_distribute.Value = $dpprogress} ),$null, $null )
                }
                Catch 
                {
                        log-item -logline "Distribution to $dp failed" -severity error
                        log-item -logline "Exception Type: $($_.Exception.GetType().FullName)" -severity "Error"
                        log-item -logline "Exception Message: $($_.Exception.Message)" -severity "Error"
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFdistribute_progress.Content = "Distribution to $dp failed"} ),$null, $null )
                }
        }
        foreach ($DPGroup in $wpfdpgroup.selecteditems)
        {
                try {
                        Start-CMContentDistribution -ApplicationName $fullname -DistributionPointGroupName $dpgroup -erroraction stop
                        log-item -logline "Starting distribution to DP group : $DPGroup"
                        $dpprogress = $dpprogress + $dpblocks
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFdistribute_progress.Content = "Starting distribution to DP group : $DPGroup"} ),$null, $null )
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFPB_Progress_distribute.Value = $dpprogress} ),$null, $null )
                        
                }
                catch {
                        log-item -logline "Distribution to $dpGroup failed" -severity error
                        log-item -logline "Exception Type: $($_.Exception.GetType().FullName)" -severity "Error"
                        log-item -logline "Exception Message: $($_.Exception.Message)" -severity "Error"
                        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFdistribute_progress.Content = "Distribution to $dpGroup failed"} ),$null, $null )
                }

        }
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFdistribute_progress.Content = "All distributions have started"} ),$null, $null )
        $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFPB_Progress_distribute.Value = 100} ),$null, $null )

}
)

$wpfgenerate_collections.add_click({
        $collname_I = $global:fullname
        $collname_u = $global:fullname
        if ($wpfprefix.text -ne "")
                {
                        $Collname_i = $wpfprefix.text + "-" + $collname_i
                        $Collname_u = $wpfprefix.text + "-" + $collname_u
                }
        if ($wpfsuffix.text -ne "")
                {
                        $collname_i = $collname_i + "-" + $wpfsuffix.text
                        $collname_U = $collname_U + "-" + $wpfsuffix.text
                }
        $collname_i = $collname_i + "-Install"
        $collname_u = $collname_u + "-Uninstall"

        try {
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFCollections_info.Content = "Start Creation of collections"} ),$null, $null )
                new-cmcollection -collectiontype device -limitingcollectionname "all systems" -name $collname_I -erroraction stop
                new-cmcollection -collectiontype device -limitingcollectionname "all systems" -name $collname_u -erroraction stop
                log-item -logline "Install collection : $collname_i created"
                log-item -logline "Uninstall collection : $collname_u created"
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFCollections_info.Content = "Collection Creation has finished"} ),$null, $null )
        }
        catch {
                log-item -logline "failed creating collections" -severity error
                $wpfCollections_info.background = "Red"
                $Form.Dispatcher.Invoke( "Render", ([Action``2[[System.Object,mscorlib],[System.Object, mscorlib]]]{$WPFCollections_info.Content = "Collection Creation has failed"} ),$null, $null )

        }
}) 

$wpfinstalltype.add_Selectionchanged(
{
Switch ($WPFInstallType.SelectedIndex)
    {
    "0" 
            {
            $wpfinstalltext1.text = "MSI Filename"
            $WPFInstallText2.text = "MSI Parameters"
            $WPFuninstallText.text = "Name in Add/Remove programs to uninstall"
            $WPFuninstallText.tooltip = "if you put in 'Adobe', it removes all versions of software that match the name 'Adobe'"
            }
    "1" 
            {
            $wpfinstalltext1.text = "Script executable"
            $WPFInstallText2.text = "Script Parameters" 
            $WPFuninstallText.text = "Uninstall Command-Line"
            $WPFuninstallText.tooltip = "Please provide the full uninstall Command-Line"          
            }
    } 
})

$wpfBTN_Lookup.add_click({
        $url = $wpfVendorLookup.text
        $url = $url.toupper()
        
        if ($url.substring(0,3) -eq "WWW")
        {
                $url = $url.trimstart("W.")
                lookup-url $url
        }
        else 
        {
                lookup-url $url
        }
})

$wpfVendorLookup.add_gotfocus({
        if($wpfVendorLookup.Tag -ne 'cleared') 
        { # clear the text box
                $wpfVendorLookup.Text = ''
                $wpfVendorLookup.Tag = 'cleared' # use any text you want to indicate that its cleared
        }
})

$wpfinputSource.add_gotfocus({

        if($wpfinputSource.Tag -ne 'cleared') 
        { # clear the text box
        $wpfinputSource.Text = ''
        $wpfinputSource.Tag = 'cleared' # use any text you want to indicate that its cleared
        }
})


$wpfinputdestination.add_gotfocus({

        if($wpfinputdestination.Tag -ne 'cleared') 
        { # clear the text box
        $wpfinputdestination.Text = ''
        $wpfinputdestination.Tag = 'cleared' # use any text you want to indicate that its cleared
        }
})

$wpfregidYY.add_gotfocus({
        if($wpfregidYY.Tag -ne 'cleared') 
        { # clear the text box
        $wpfregidYY.Text = ''
        $wpfregidYY.Tag = 'cleared' # use any text you want to indicate that its cleared
        }
})

$wpfregidMM.add_gotfocus({
        if($wpfregidMM.Tag -ne 'cleared') 
        { # clear the text box
        $wpfregidMM.Text = ''
        $wpfregidMM.Tag = 'cleared' # use any text you want to indicate that its cleared
        }
})

$wpfregidDomain.add_gotfocus({
        if($wpfregidDomain.Tag -ne 'cleared') 
        { # clear the text box
        $wpfregidDomain.Text = ''
        $wpfregidDomain.Tag = 'cleared' # use any text you want to indicate that its cleared
        }
})
$form.title = "Powershell App deployment Tookit - GUI - Version $Gui_version"
$Form.ShowDialog() | out-null
