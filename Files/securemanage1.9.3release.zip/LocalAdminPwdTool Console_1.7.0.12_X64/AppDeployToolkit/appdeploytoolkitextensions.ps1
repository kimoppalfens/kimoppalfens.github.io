<#
.SYNOPSIS
	This script is a template that allows you to extend the toolkit with your own custom functions.
.DESCRIPTION
	The script is automatically dot-sourced by the AppDeployToolkitMain.ps1 script.
.NOTES
    Toolkit Exit Code Ranges:
    60000 - 68999: Reserved for built-in exit codes in Deploy-Application.ps1, Deploy-Application.exe, and AppDeployToolkitMain.ps1
    69000 - 69999: Recommended for user customized exit codes in Deploy-Application.ps1
    70000 - 79999: Recommended for user customized exit codes in AppDeployToolkitExtensions.ps1
.LINK 
	http://psappdeploytoolkit.com
#>
[CmdletBinding()]
Param (
)

##*===============================================
##* VARIABLE DECLARATION
##*===============================================

# Variables: Script
[string]$appDeployToolkitExtName = 'PSAppDeployToolkitExt'
[string]$appDeployExtScriptFriendlyName = 'App Deploy Toolkit Extensions'
[version]$appDeployExtScriptVersion = [version]'1.5.0'
[string]$appDeployExtScriptDate = '06/11/2015'
[hashtable]$appDeployExtScriptParameters = $PSBoundParameters

##*===============================================
##* FUNCTION LISTINGS
##*===============================================


#region Function Write-SWIDTag
Function Write-SWIDTag {
<#
.SYNOPSIS
	Writes an SWIDTag xmlfile as specified in ISO/IEC 19770 around Software assetmanagement .DESCRIPTION
	Writes an SWIDTag xmlfile as specified in ISO/IEC 19770 around Software assetmanagement
    Which can help alot in software asset management and license compliance .PARAMETER SWIDTagFilename 
    eg: regid.1995-08.com.techsmith Snagit 12.swidtag saved in $env:ProgramData 
.PARAMETER EntitlementRequired
	Does the software require a license to be used. 
    Optional - Default is $true 
.PARAMETER ProductTitle
    Title of the software installed. 
    Optional - Default is $appname when used in powershell app deployment toolkit 
.PARAMETER ProductVersion
    Version of the software in x.y.z.w format, where x is major, y is minor, z is build and w is review. 
    Optional - Default is $appversion when used in powershell app deployment toolkit
    If your product version has fewer levels, complete with 0 for any level (minor, build or review) you don't have.
.PARAMETER CreatorName
	Name of the software creator. 
    Optional - Default is $appvendor when used in powershell app deployme
	Path of the SWIDTag file to create. 
    Optional - Default $env:ProgramData + '\' + $CreatorRegid + '\' + $creatorRegid + ' ' + $ProductTitle + ' ' + $ProductVersion +'.swidtag'
.PARAMETER CreatorRegid
	Regid of the software creator. Regid's in ISO/IEC 19770 are defined as the word regid. followed by the date you owned a particular DNS domain in YYYY-MM format
    followed by the domain name in reverse formatting. eg: regid.1991-06.com.microsoft 
    Mandatory field
.PARAMETER LicensorName
	Name of the software licensor. Optional - Default is $appvendor when used in powershell app deployment toolkit 
.PARAMETER LicensorRegid
	Regid of the software Licensor. Regid's in ISO/IEC 19770 are defined as the word regid. followed by the date you owned a particular DNS domain in YYYY-MM format
    followed by the domain name in reverse formatting. eg: regid.1991-06.com.microsoft
    Optional - Default is $CreatorRegid value 
.PARAMETER SoftwareUniqueID
    UniqueID assigned to the software.
    Can be set in GUID format 8HexCharacters-4HexCharacters-4HexCharacters-4HexCharacters-12HexCharacters, the format used by MSI productid's
    eg: BDFD9ADC-3F97-4A8A-A533-987B21776449
    Optional - Default is $producttitle + ' ' +  $productversion
.PARAMETER TagCreatorRegid
    Regid of the TagCreator. Regid's in ISO/IEC 19770 are defined as the word regid. followed by the date you owned a particular DNS domain in YYYY-MM format
    followed by the domain name in reverse formatting. eg: regid.1991-06.com.microsoft
    Optional - Default is $CreatorRegid value



.EXAMPLE
	Write-SWIDTag -CreatorRegid 'regid.2008-03.be.oscc' 
    Write a software id tag using the minimum set of parameters to specify, other parameters will use the powershell app deployment toolkit variables for software title, version, vendor to generate the tag.
    This example will not work outside the Powershell app deployment toolkit .EXAMPLE
    Write-SWIDTag -ProductTitle "SWIDTagHandler" -ProductVersion "1.2.3.4" -CreatorName "OSCC" -CreatorRegid "regid.2008-03.be.oscc" -SoftwareUniqueid "a6ca313e-c7ae-447c-9ee0-bd872278c166" 
    Write a software id tag using the minimum set of parameters when used outside of the powershell app deployment toolkit
    This generates a tag for a product called Swidtaghandler with version 1.2.3.4 by Software vendor OSCC, oscc's regid is regid.2008-30.BE.OSCC .NOTES
    You can generate a guid in powershell using this code [guid]::NewGuid(), don't generate a new one for every install. The idea of the guid is that is the same on every machine you write this swidtag to
    If this is to install an msi, the ps app deployment toolkit containts a function to get the productcode from that msi, please use that productcode as your guid, the following command returns the productcode from an msi.
    Get-MsiTableProperty -Path RelativePathToMsiFile | select productcode .NOTES
    the regid as definied in ISO19770 is the literal string regid, followed by the date the domain was first registered in YYYY-MM format, followed by the domain reversed
    eg: regid.1991-06.com.microsoft
    You can typically find the registration date using whois

.LINK
	http://psappdeploytoolkit.codeplex.com
.LINK
    http://www.scug.be/thewmiguy
.LINK
    http://www.oscc.be
.LINK
    https://technet.microsoft.com/en-us/library/gg681998.aspx#BKMK_WhatsNewSP1
.LINK
    http://www.scconfigmgr.com/2014/08/22/how-to-get-msi-file-information-with-powershell/
#>
	[CmdletBinding()]
	Param (

		[Parameter(Mandatory=$false,
        HelpMessage='Does the software license require an entitlement also known as software usage right or license?')]
		[boolean]$EntitlementRequired = $true,

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='Name of the software to add to the swidtag, default is the $appName variable from the PS app deploy toolkit.')]
        [Alias('SoftwareName','ApplicationName','Name')]
		[ValidateNotNullorEmpty()]
        [string] $ProductTitle = $appName_withspace, 

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='32 or 64 bit architecture, default is the $appArch variable from the PS app deploy toolkit.')]
        [Alias('AppArchitecture','ApplicationArchitecture','BitNess')]
		[ValidateSet('x86','X86','x64','X64')]
        [string] $ProductArch = $appArch,

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='Version of the software to add to the swidtag, in 4 digit format separated by the . character')]
        [Alias('SoftwareVersion','ApplicationVersion','Version')]
		#[ValidatePattern("^\d+\.\d+\.\d+\.\d+$")]
        [string] $ProductVersion = $appVersion,  

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='Path, including filename of the swidtag to generate.')]
        [Alias('Filename')]
        [string] $SWIDTagFilename = $env:ProgramData + '\' + $CreatorRegid + '\' + $creatorRegid + ' ' + $ProductTitle + ' ' + $ProductVersion + ' ' + $productArch +'.swidtag', 

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='Vendor of the software to add to the swidtag, default is the $appvendor variable in the PS app deploy toolkit.')]
        [Alias('SoftwareVendor','Vendor','Manufacturer')]
		[ValidateNotNullorEmpty()]
        [string] $CreatorName = $appVendor_withspace, 

        [Parameter(Mandatory=$True,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='Regid of the Vendor of the software to add to the swidtag, format is: regid.YYYY-MM.FirstLevelDomain.SecondLeveldomain, eg: regid.1991-06.com.microsoft the date is the date when the domain referenced was first registered')]
        [Alias('Regid','VendorRegid')]
        #[ValidatePattern("^regid\.(19|20)\d\d-(0[1-9]|1[012])\.[A-Za-z]{2,6}\.[A-Za-z0-9-]{1,63}.+$")]
        [string]$CreatorRegid,

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='LicensorName of the software to add to the swidtag.')]
		[ValidateNotNullorEmpty()]
        [string] $LicensorName = $CreatorName, 

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='Licensor Regid of the software to add to the swidtag, format is identical to $CreatorRegid')]
        #[ValidatePattern("^regid\.(19|20)\d\d-(0[1-9]|1[012])\.[A-Za-z]{2,6}\.[A-Za-z0-9-]{1,63}.+$")]
        [string]$LicensorRegid = $creatorRegid,

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='Uinqueid to add to the swid tag, format is: 8 hex chars-4 hex chars-4 hex chars-4 hex chars-12 hex chars. If this is an MSI install use the MSI ProductID, guid can but does not have to be enclosed in {}')]
        [Alias('UniqueId','GUID')]
        #[ValidatePattern("^{?[A-Z0-9]{8}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{12}}?$")]
		[string]$SoftwareUniqueid=$ProductTitle  + ' ' + $ProductVersion,

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='Tag creator name of the software to add to the swidtag.')]
		[ValidateNotNullorEmpty()]
        [string] $TagCreatorName = $CreatorName, 

        [Parameter(Mandatory=$False,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='TagCreator Regid of the software to add to the swidtag, format is identical to $CreatorRegid')]
        #[ValidatePattern("^regid\.(19|20)\d\d-(0[1-9]|1[012])\.[A-Za-z]{2,6}\.[A-Za-z0-9-]{1,63}.+$")]
        [string]$TagCreatorRegid = $creatorRegid,

		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
		[boolean]$ContinueOnError = $true
	)
	
	Begin {
		## Get the name of this function and write header
		[string]${CmdletName} = $PSCmdlet.MyInvocation.MyCommand.Name
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -CmdletBoundParameters $PSBoundParameters -Header
	}
	Process {
		Try {
                # this is where the document will be saved:
                $Path = $SWIDTagFilename.Replace(' ','_')
                $SWIDTagFolder = split-path $Path

				Write-Log -Message "Testing whether [$SWIDTagFolder] exists, if not path is recursively created." -Source ${CmdletName}
                if(-not(test-path($SWIDTagFolder)))
                {
				Write-Log -Message "Folder [$SWIDTagFolder] does not exist, recursively creating it." -Source ${CmdletName}
                    New-Item -path $SWIDTagFolder -type directory
				Write-Log -Message "Folder [$SWIDTagFolder] is successfully created." -Source ${CmdletName}
                }
                else
                {
				Write-Log -Message "Folder [$SWIDTagFolder] already exists, no need to create it." -Source ${CmdletName}
                }


 
                # get an XMLTextWriter to create the XML and set the encoding to UTF8
				Write-Log -Message "Creating XMLTextWriter object and set encoding to UTF8." -Source ${CmdletName}
                $encoding = [System.Text.Encoding]::UTF8
                Write-Log -Message "Creating XMLTextWriter file in path $Path." -Source ${CmdletName}
                Write-Log -Message "Creating XMLTextWriter file in path $SWIDTagFileName." -Source ${CmdletName}
                $XmlWriter = New-Object System.XMl.XmlTextWriter($Path,$encoding)
 
                # choose a pretty formatting: (set Indentation to 1 Tab)
				Write-Log -Message "Setting indentation of the file to 1 Tab." -Source ${CmdletName}
                $xmlWriter.Formatting = 'Indented'
                $xmlWriter.Indentation = 1
                $XmlWriter.IndentChar = "`t"

 
                # write the header
				Write-Log -Message "Writing SWIDTag header." -Source ${CmdletName}
                $xmlWriter.WriteStartDocument("true")
                $xmlWriter.WriteProcessingInstruction("xml-stylesheet", "type='text/xsl' href='style.xsl'")
                $XmlWriter.WriteStartElement("swid","software_identification_tag","http://standards.iso.org/iso/19770/-2/2008/schema.xsd")
                $XmlWriter.WriteAttributeString("xsi:schemalocation","http://standards.iso.org/iso/19770/-2/2008/schema.xsd software_identification_tag.xsd")
                $XmlWriter.WriteAttributeString("xmlns:xsi","http://www.w3.org/2001/XMLSchema-instance")
                $XmlWriter.WriteAttributeString("xmlns:ds","http://www.w3.org/2000/09/xmldsig#")
                # write the mandatory elements, and the sccm supported elements of an iso 19770 swidtag
				Write-Log -Message "Writing EntitlementRequired field, settng it to [$EntitleMentRequired]." -Source ${CmdletName}
                if ($EntitlementRequired)
                {
                    $XmlWriter.WriteElementString("swid:entitlement_required_indicator","true")
                }
                else
                {
                    $XmlWriter.WriteElementString("swid:entitlement_required_indicator","false")
                }
				Write-Log -Message "Writing other SWIDTag elements." -Source ${CmdletName}
                Write-Log -Message "Writing ProductTitle, setting it to [$ProductTitle]" -Source ${CmdletName}
                $XmlWriter.WriteElementString("swid:product_title",$ProductTitle)
                $XmlWriter.WriteStartElement("swid:product_version")
                $XmlWriter.WriteElementString("swid:name",$ProductVersion)
                $XmlWriter.WriteStartElement("swid:numeric")
                if (!($productversion.Contains('.')))
                {
                    Write-Log -Message "ProductVersion [$ProductVersion] is not in the correct format. Altering format to comply with SwidTag format, appending .0. New Productversion is [$ProductVersion.0]"
                    $productversion = $productversion + '.0'
                }

                Write-Log -Message "Writing ProductVersion, setting it to [$ProductVersion]" -Source ${CmdletName}
                $splitProductVersion = $ProductVersion.Split('.')
                $XmlWriter.WriteElementString("swid:major",$splitProductversion[0])
                $XmlWriter.WriteElementString("swid:minor",$splitProductversion[1])
                $XmlWriter.WriteElementString("swid:build",$splitProductversion[2])
                $XmlWriter.WriteElementString("swid:review",$splitProductversion[3])
                $XmlWriter.WriteEndElement();
                $XmlWriter.WriteEndElement();
                $XmlWriter.WriteStartElement("swid:software_creator")
                $XmlWriter.WriteElementString("swid:name",$CreatorName)
                $XmlWriter.WriteElementString("swid:regid",$creatorRegid)
                $XmlWriter.WriteEndElement();
                $XmlWriter.WriteStartElement("swid:software_licensor")
                $XmlWriter.WriteElementString("swid:name",$LicensorName)
                $XmlWriter.WriteElementString("swid:regid",$LicensorRegid)
                $XmlWriter.WriteEndElement();
                $XmlWriter.WriteStartElement("swid:software_id")
                if ($SoftwareUniqueid.ToString().StartsWith('{'))
                {
                  $swid = $SoftwareUniqueid.ToString().Substring(1,36)
                  Write-Log -Message "Writing SoftwareuniqueId [$swid] to swid tag." -Source ${CmdletName}
                  $XmlWriter.WriteElementString("swid:unique_id",$SoftwareUniqueid.ToString().Substring(1,36))
                }
                else
                {
                  Write-Log -Message "Writing SoftwareuniqueId [$SoftwareUniqueid] to swid tag." -Source ${CmdletName}
                    $XmlWriter.WriteElementString("swid:unique_id",$SoftwareUniqueid)
                }
                $XmlWriter.WriteElementString("swid:tag_creator_regid",$TagCreatorRegid)
                $XmlWriter.WriteEndElement();
                $XmlWriter.WriteStartElement("swid:tag_creator")
                $XmlWriter.WriteElementString("swid:name",$TagCreatorName)
                $XmlWriter.WriteElementString("swid:regid",$TagCreatorRegid)
                $XmlWriter.WriteEndElement();
                $xmlWriter.Flush()
                $xmlWriter.Close()
		}
		Catch {
			Write-Log -Message "Failed to write swidtag to destination [$SWIDTagFilename]. `n$(Resolve-Error)" -Severity 3 -Source ${CmdletName}
			If (-not $ContinueOnError) {
				Throw "Failed to write swidtag to destination [$SWIDTagFilename]: $($_.Exception.Message)"
			}
		}
	}
	End {
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -Footer
	}
}
#endregion



##*===============================================
##* END FUNCTION LISTINGS
##*===============================================

##*===============================================
##* SCRIPT BODY
##*===============================================

If ($scriptParentPath) {
	Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] dot-source invoked by [$(((Get-Variable -Name MyInvocation).Value).ScriptName)]" -Source $appDeployToolkitExtName
}
Else {
	Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] invoked directly" -Source $appDeployToolkitExtName
}

##*===============================================
##* END SCRIPT BODY
##*===============================================
# SIG # Begin signature block
# MIIcdgYJKoZIhvcNAQcCoIIcZzCCHGMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCBdgd+RV6MhDO1
# u62G4mqH/DM7ocvcsBHY8JUxVQrmcqCCF4AwggUJMIID8aADAgECAhANuwjc1awR
# STlYhzG60ROyMA0GCSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNV
# BAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcN
# MTcwOTE4MDAwMDAwWhcNMTkwMzA4MTIwMDAwWjBGMQswCQYDVQQGEwJCRTEPMA0G
# A1UEBxMGSGVyZW50MRIwEAYDVQQKEwlPU0NDIEJWQkExEjAQBgNVBAMTCU9TQ0Mg
# QlZCQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMeyYUwgipNp7rRm
# tBS3fcYqTGCvCqee7Dj9Weh5bgx/u6vIZna9Bp/zf5AvtGfIxHOXI0XnrzhPyC5/
# ZwzKdm0sPBb54dv8oIBTLRzuNJhfzwslVf4TvrJlVKZOkRisdnhGMw0kbIcXkaZb
# OpC0bcq43cwWZIr4NR20W39TiauezOQHMtRFxXLrM3mmn4UnCjpYT2XvsWbgtaIi
# tjowbPi1GbxxlbtKmIFYR6GQiQrA7rOMuo2pt2dJQ//tUM7d4/orUIm/RkDkI6f/
# iY6rB385JHXuqi4dW1y3gam2EVT++ni5H+yZ5Kqg7aEAXSsvHng9Jsw2ADr+p6E3
# DM+3CU0CAwEAAaOCAcUwggHBMB8GA1UdIwQYMBaAFFrEuXsqCqOl6nEDwGD5LfZl
# dQ5YMB0GA1UdDgQWBBRj1Tmj8IeGT5/pbLcDkFt8YdN6SzAOBgNVHQ8BAf8EBAMC
# B4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwdwYDVR0fBHAwbjA1oDOgMYYvaHR0cDov
# L2NybDMuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC1jcy1nMS5jcmwwNaAzoDGG
# L2h0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQtY3MtZzEuY3Js
# MEwGA1UdIARFMEMwNwYJYIZIAYb9bAMBMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8v
# d3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCAYGZ4EMAQQBMIGEBggrBgEFBQcBAQR4MHYw
# JAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBOBggrBgEFBQcw
# AoZCaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0U0hBMkFzc3Vy
# ZWRJRENvZGVTaWduaW5nQ0EuY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQEL
# BQADggEBAGYRcucefTNQbnJwBdy/82ouRUL8xGd8RwY1gabL0UI8qEr/xz387dJn
# +RVPOdvkpGFLwhOT1ADeOBrJciAdIpabE/OwWYwWsdmisMACzVCNrqOA+FfIVCwf
# /OTMa6XWI0/TRkpjNhPDTXcML8pp3pKSDTglWSXjAgyjfWEBq588eFuAaIZHmbyj
# 9Rom8ezaQ6DXIurRRT/uDvugIJ6r7ZRprT3/6oQBBLVybWYKTlsFckqsWXSD6TTZ
# QrDca0JS9HAAWsKAc2t0RKyFizuSjv3TuVSFNTJGb5R52USyoRsV8qtm6oHz9w7r
# baKI8WvFZdr5bvI0DQqco3WbaMcZSPswggUwMIIEGKADAgECAhAECRgbX9W7ZnVT
# Q7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxE
# aWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMT
# G0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBaFw0y
# ODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/lqJ3b
# Mtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fTeyOU
# 5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqHCN8M
# 9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+bMt+
# dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLoLFH3
# c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIByTAS
# BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggr
# BgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHoweDA6
# oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElE
# Um9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwAAgQw
# KjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAKBghg
# hkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0jBBgw
# FoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7sDVok
# s/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGSdQ9R
# tG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6r7VR
# wo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo+MUS
# aJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qzsIzV
# 6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHqaGxE
# MrJmoecYpJpkUe8wggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0GCSqG
# SIb3DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFz
# c3VyZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBaMEcx
# CzAJBgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGlnaUNl
# cnQgVGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLjntVa
# Y1sCSVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0ZLZQ
# t/USs3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafeTl/i
# qLYtWQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+z+yM
# DDZbesF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlXmVYw
# k/PJYczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB/wQE
# AwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYD
# VR0gBIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxodHRw
# czovL3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBB
# AG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBh
# AHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBj
# AGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABT
# ACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABB
# AGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBh
# AGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBh
# AHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAu
# MAsGCWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cCzTAd
# BgNVHQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDagNIYy
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5j
# cmwwOKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3Vy
# ZWRJRENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDov
# L29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5k
# aWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG9w0B
# AQUFAAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakbvFoW
# OQCd42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZBWs1
# kBCge5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/jbRcT
# Bu7kA7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenYk+VV
# FvC7Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOSK2vC
# UcIKSK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBs0wggW1oAMCAQICEAb9+QOWA63q
# AArrPye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoT
# DERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UE
# AxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAwMFoX
# DTIxMTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
# IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNl
# cnQgQXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEA6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+etSQV
# wpi5tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cxSIB8
# HqIPkg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0PdAug7
# Pe2xQaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLOBq6t
# hG9IhJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4aH63
# 1XcKJ1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQDAgGG
# MDsGA1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsGAQUF
# BwMEBggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAABBDCC
# AaQwOgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1jcHMt
# cmVwb3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBz
# AGUAIABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBv
# AG4AcwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAg
# AHQAaABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAg
# AHQAaABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBt
# AGUAbgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0
# AHkAIABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABo
# AGUAcgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9
# bAMVMBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUF
# BzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6
# Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5j
# cnQwgYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0LmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0OBBYE
# FBUAEisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6en
# IZ3zbcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukxR6tW
# XHvVDQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW0eu7
# NoR3zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz5Js5
# p8T1zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj++wc4
# Tw3GXZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9fAqg
# 7iwIVYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYIETDCC
# BEgCAQEwgYYwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZ
# MBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hB
# MiBBc3N1cmVkIElEIENvZGUgU2lnbmluZyBDQQIQDbsI3NWsEUk5WIcxutETsjAN
# BglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqG
# SIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3
# AgEVMC8GCSqGSIb3DQEJBDEiBCDK0QRRxvQ5p5+D6QL5VkGpGX5koesC16+rzcDV
# AZztljANBgkqhkiG9w0BAQEFAASCAQAUpbYqBzpyyLgKGCfWB6YuneOCG1nG7Alr
# 3H6N6RaX9AGh47TJkiSuo+Rm2OwLsol7RylveoqsNmt3WsUXHm0fhiiP/SgGzP6/
# 0zmNII2GrxstMhw2aBfTiNU/0JWK5HZp4QQ+noq71UK6VOtN2N1g96L8nwD7YpzH
# aAG+/jESdw4cMOp6cR42J8fjkLjZf523b9Y2aZvsTGZGLDK+MqgdJ+r/CDeKQbvn
# rbiR+m7s/8tGixMW/YQwkeDDAZWwC2776Ae9VQ2Zvbt53HTW9Zmm8Loj2kRSie+T
# zJpZd6KlWi9BL25QX9DM/J+lZmkizCMJUOMY/VFGvHUVu5YzO1vQoYICDzCCAgsG
# CSqGSIb3DQEJBjGCAfwwggH4AgEBMHYwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoT
# DERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UE
# AxMYRGlnaUNlcnQgQXNzdXJlZCBJRCBDQS0xAhADAZoCOv9YsWvW1ermF/BmMAkG
# BSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJ
# BTEPFw0xODA3MTIxMjUxMDRaMCMGCSqGSIb3DQEJBDEWBBRSTfYtU+fNgz0qefqp
# kN2fmy7jQDANBgkqhkiG9w0BAQEFAASCAQBFgPynnrtspeI5iURiX6uzNjwA9x7W
# lqQVap1X4N/H3GNMyTxXO/HqQSOlFZgkOweBf11U7/J0gDT5nxg86jBVvesoKPqs
# B/IBFf895D0uuJQ6q4RhD4QD1KSpELn3RPWf6Kgdr2TCLYMXNZWxngqYCAeEPpPp
# ZGxcZnSFc5sLaVkgbdz2jadLAEU1cjXD+oaJznThZV7p2D4oo1cSaJMg1hKlbset
# gD7TD3sP09VfjIxh0GweDR2Aq0dFoxOeSzvCXbH1Ms111hHt9FbwETL8mqZ2WFVF
# vCcuHKX9N/oHjCBDQmwFWlqBr87Q95rFkhmON7TC+tMcSzxa0k3ut53E
# SIG # End signature block
