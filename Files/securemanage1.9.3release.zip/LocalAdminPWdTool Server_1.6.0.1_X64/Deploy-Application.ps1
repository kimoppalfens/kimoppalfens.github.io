### Generated FILE from GUI with GUIToolkit version 1.2 ###
<#
.SYNOPSIS
	This script performs the installation or uninstallation of an application(s).
.DESCRIPTION
	The script is provided as a template to perform an install or uninstall of an application(s).
	The script either performs an "Install" deployment type or an "Uninstall" deployment type.
	The install deployment type is broken down into 3 main sections/phases: Pre-Install, Install, and Post-Install.
	The script dot-sources the AppDeployToolkitMain.ps1 script which contains the logic and functions required to install or uninstall an application.
.PARAMETER DeploymentType
	The type of deployment to perform. Default is: Install.
.PARAMETER DeployMode
	Specifies whether the installation should be run in Interactive, Silent, or NonInteractive mode. Default is: Interactive. Options: Interactive = Shows dialogs, Silent = No dialogs, NonInteractive = Very silent, i.e. no blocking apps. NonInteractive mode is automatically set if it is detected that the process is not user interactive.
.PARAMETER AllowRebootPassThru
	Allows the 3010 return code (requires restart) to be passed back to the parent process (e.g. SCCM) if detected from an installation. If 3010 is passed back to SCCM, a reboot prompt will be triggered.
.PARAMETER TerminalServerMode
	Changes to "user install mode" and back to "user execute mode" for installing/uninstalling applications for Remote Destkop Session Hosts/Citrix servers.
.PARAMETER DisableLogging
	Disables logging to file for the script. Default is: $false.
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeployMode 'Silent'; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -AllowRebootPassThru; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeploymentType 'Uninstall'; Exit $LastExitCode }"
.EXAMPLE
    Deploy-Application.exe -DeploymentType "Install" -DeployMode "Silent"
.NOTES
	Toolkit Exit Code Ranges:
	60000 - 68999: Reserved for built-in exit codes in Deploy-Application.ps1, Deploy-Application.exe, and AppDeployToolkitMain.ps1
	69000 - 69999: Recommended for user customized exit codes in Deploy-Application.ps1
	70000 - 79999: Recommended for user customized exit codes in AppDeployToolkitExtensions.ps1
.LINK 
	http://psappdeploytoolkit.com
#>
[CmdletBinding()]
Param (
	[Parameter(Mandatory=$false)]
	[ValidateSet('Install','Uninstall')]
	[string]$DeploymentType = 'Install',
	[Parameter(Mandatory=$false)]
	[ValidateSet('Interactive','Silent','NonInteractive')]
	[string]$DeployMode = 'Interactive',
	[Parameter(Mandatory=$false)]
	[switch]$AllowRebootPassThru = $false,
	[Parameter(Mandatory=$false)]
	[switch]$TerminalServerMode = $false,
	[Parameter(Mandatory=$false)]
	[switch]$DisableLogging = $false,
	[Parameter(Mandatory=$false)]
	[String]$TrustedHostsValue = "*",
	[Parameter(Mandatory=$false)]
	[switch]$DistributeToDPGroup = $false,
	[Parameter(Mandatory=$false)]
	[String]$DPGroupName = $false,
	[Parameter(Mandatory=$false)]
	[switch]$ForceUpgrade = $false,
	[Parameter(Mandatory=$true,HelpMessage="Enter a UNC path, the User account performing the installation needs write access to the share.")]
    [ValidateScript({
        If ([bool]([System.Uri]$_).IsUnc)
        {$True}
        else
        {Throw [System.Management.Automation.ValidationMetadataException] "The path '${_}' is not a container."}     
        })]
    [string]$PackagePath
    )


Try {
	## Set the script execution policy for this process
	Try { Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Scope 'Process' -Force -ErrorAction 'Stop' } Catch {}
	
	##*===============================================
	##* VARIABLE DECLARATION
	##*===============================================
	## Variables: Application
	[string]$appVendor = 'OSCC'
	[string]$appVendor_WithSpace = 'OSCC'
	[string]$appName = 'Secure Manage Server'
	[string]$appName_WithSpace = 'Secure Manage Server'
	[string]$appVersion = '1.6.0.0'
	[string]$appArch = 'X64'
	[string]$appLang = ''
	[string]$appRevision = ''
	[string]$appVendorSWIDTAGRegID = 'RegID.2008-03.Be.Oscc'
	[string]$appScriptVersion = '1.0.0'
	[string]$appScriptDate = '30/04/2020'
	[string]$appScriptAuthor = 'OSCC'
	##*===============================================
	## Variables: Install Titles (Only set here to override defaults set by the toolkit)
	[string]$installName = ''
	[string]$installTitle = ''
	
	##* Do not modify section below
	#region DoNotModify
	
	## Variables: Exit Code
	[int32]$mainExitCode = 0
	
	## Variables: Script
	[string]$deployAppScriptFriendlyName = 'Deploy Application'
	[version]$deployAppScriptVersion = [version]'3.6.9'
	[string]$deployAppScriptDate = '02/12/2017'
	[hashtable]$deployAppScriptParameters = $psBoundParameters
	
	## Variables: Environment
	If (Test-Path -LiteralPath 'variable:HostInvocation') { $InvocationInfo = $HostInvocation } Else { $InvocationInfo = $MyInvocation }
	[string]$scriptDirectory = Split-Path -Path $InvocationInfo.MyCommand.Definition -Parent
	
	## Dot source the required App Deploy Toolkit Functions
	Try {
		[string]$moduleAppDeployToolkitMain = "$scriptDirectory\AppDeployToolkit\AppDeployToolkitMain.ps1"
		If (-not (Test-Path -LiteralPath $moduleAppDeployToolkitMain -PathType 'Leaf')) { Throw "Module does not exist at the specified location [$moduleAppDeployToolkitMain]." }
		If ($DisableLogging) { . $moduleAppDeployToolkitMain -DisableLogging } Else { . $moduleAppDeployToolkitMain }
	}
	Catch {
		If ($mainExitCode -eq 0){ [int32]$mainExitCode = 60008 }
		Write-Error -Message "Module [$moduleAppDeployToolkitMain] failed to load: `n$($_.Exception.Message)`n `n$($_.InvocationInfo.PositionMessage)" -ErrorAction 'Continue'
		## Exit the script, returning the exit code to SCCM
		If (Test-Path -LiteralPath 'variable:HostInvocation') { $script:ExitCode = $mainExitCode; Exit } Else { Exit $mainExitCode }
	}
	
	#endregion
	##* Do not modify section above
	##*===============================================
	##* END VARIABLE DECLARATION
	##*===============================================
		
	If ($deploymentType -ine 'Uninstall') {
		##*===============================================
		##* PRE-INSTALLATION
		##*===============================================
		[string]$installPhase = 'Pre-Installation'
		
		## Show Welcome Message, close Internet Explorer if required, allow up to 3 deferrals, verify there is enough disk space to complete the install, and persist the prompt
		#Show-InstallationWelcome -CloseApps 'iexplore' -AllowDefer -DeferTimes 3 -CheckDiskSpace -PersistPrompt
		
		## Show Progress Message (with the default message)
		Show-InstallationProgress
		
		## <Perform Pre-Installation tasks here>
		
		
		##*===============================================
		##* INSTALLATION 
		##*===============================================
		[string]$installPhase = 'Installation'
		
		## Handle Zero-Config MSI Installations
		If ($useDefaultMsi) {
			[hashtable]$ExecuteDefaultMSISplat =  @{ Action = 'Install'; Path = $defaultMsiFile }; If ($defaultMstFile) { $ExecuteDefaultMSISplat.Add('Transform', $defaultMstFile) }
			Execute-MSI @ExecuteDefaultMSISplat; If ($defaultMspFiles) { $defaultMspFiles | ForEach-Object { Execute-MSI -Action 'Patch' -Path $_ } }
		}
		
		## <Perform Installation tasks here>
	    
        If ($PackagePath.EndsWith('\'))
        {
            $PackagePath = $PackagePath.TrimEnd('\')
        }

        if (-not (Test-Path env:sms_admin_ui_path))
        {
            $ENV:SMS_ADMIN_UI_PATH = ($((Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\ConfigMgr10\AdminUI\QueryProcessors\WQL -Name "assembly path")."assembly path") | split-path -Parent)+"\i386"
             
		}
		
#region Copy tasksequence
		if (-not (test-path $PackagePath))
		{
			Write-Log -Message "Packagepath does not exist, creating it."
			New-Folder -Path $PackagePath
		}

		if (-not (test-path "$packagepath\Secure manage exported tasksequence.zip"))
		{
            $PackagePath = $PackagePath + "\OSCC - Secure Manage"
        }

		Write-Log -Message "Copying tasksequence export files to $packagepath."
		Copy-File -Path "$DirSupportFiles\Tasksequencesources" -Destination $PackagePath -Recurse
		get-childitem -path $packagepath -Recurse | Unblock-File -ErrorAction SilentlyContinue
#endregion

		Unblock-File -Path "$DirSupportFiles\TSSetLocalAdminPW.mof"        
		Copy-File -Path "$DirSupportFiles\TSSetLocalAdminPW.mof" -Destination "$env:SMS_LOG_PATH\..\"

		

#region set up configmgr connection
        Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1"
        $Sitecode = (Get-PSDrive -PSProvider CMSite).name
		Set-Location ($Sitecode + ":")
#endregion
#region AddInventoryClass
<#		
# Get a reference to the SMS_InventoryClassProperty WMI class
$InvClassPropClass = [wmiclass]"root\sms\site_$Sitecode`:SMS_InventoryClassProperty"

# Create new instance of SMS_InventoryClassProperty
$Property1 = $InvClassPropClass.CreateInstance()
# Define the property name
$Property1.PropertyName = 'KeyVersion'
# The Name property is the unique "key" property of the Win32_PageFileUsage class
$Property1.IsKey = $true
# Win32_PageFileUsage.Name is a string, so we use the integer value: 8
$Property1.Type = 8

# Create new instance of SMS_InventoryClassProperty
$Property2 = $InvClassPropClass.CreateInstance()
# Define the property name
$Property2.PropertyName = 'LastSuccessfulAttempt'
# PeakUsage is NOT the unique "key" property of the Win32_PageFileUsage class
$Property2.IsKey = $false
# Win32_PageFileUsage.PeakUsage is a Uint32, so we use the integer value: 19
$Property2.Type = 101

# Create new instance of SMS_InventoryClassProperty
$Property3 = $InvClassPropClass.CreateInstance()
# Define the property name
$Property3.PropertyName = 'LicensesUsed'
# CurrentUsage is NOT the unique "key" property of the Win32_PageFileUsage class
$Property3.IsKey = $false
# Win32_PageFileUsage.CurrentUsage is a Uint32, so we use the integer value: 19
$Property3.Type = 19

# Create new instance of SMS_InventoryClassProperty
$Property4 = $InvClassPropClass.CreateInstance()
# Define the property name
$Property4.PropertyName = 'Version'
# AllocatedBaseSize is NOT the unique "key" property of the Win32_PageFileUsage class
$Property4.IsKey = $false
# Win32_PageFileUsage.AllocatedBaseSize is a Uint32, so we use the integer value: 19
$Property4.Type = 8

# Create new instance of SMS_InventoryClassProperty
$Property5 = $InvClassPropClass.CreateInstance()
# Define the property name
$Property5.PropertyName = 'WrittenValue'
# AllocatedBaseSize is NOT the unique "key" property of the Win32_PageFileUsage class
$Property5.IsKey = $false
# Win32_PageFileUsage.AllocatedBaseSize is a Uint32, so we use the integer value: 19
$Property5.Type = 8


# Get a reference to the SMS_InventoryClass class so we can instantiate it
$InventoryClass = [wmiclass]"root\sms\site_$Sitecode`:SMS_InventoryClass"

# Create new instance of the SMS_InventoryClass class
$NewInvClass = $InventoryClass.CreateInstance()
# We want the class definition to be removable later on
$NewInvClass.IsDeletable = $true
# The WMI class name we are pointing to
$NewInvClass.ClassName = 'SecureManageStatus'
# The WMI namespace that the WMI class is located in
$NewInvClass.Namespace = '\\.\root\OSCC\SecureManage'
# The SMS Reporting ClassID (used to generate SQL tables / view)
$NewInvClass.SMSClassID = 'MICROSOFT|SECUREMANAGESTATUS|1.0'
# The SMS Group Name (it's the "friendly name" used in Resource Explorer)
$NewInvClass.SMSGroupName = 'SecureManageStatus'

$NewInvClass.Properties += [System.Management.ManagementObject]$Property1
$NewInvClass.Properties += [System.Management.ManagementObject]$Property2
$NewInvClass.Properties += [System.Management.ManagementObject]$Property3
$NewInvClass.Properties += [System.Management.ManagementObject]$Property4
$NewInvClass.Properties += [System.Management.ManagementObject]$Property5

# Commit the inventory class instance to the provider
$NewInvClass.Put()
#>
#endregion

		
#region status message query
        Write-Log -Message "Testing if  status message query for OSCC Secure Manage already exists" -Source 'Install' -LogType 'CMTrace'
        if ((Get-CMStatusMessageQuery -name 'OSCC Secure Manage actions triggered').count -eq 0)
        {
            Write-Log -Message "Query did not exist, Creating status message query for OSCC Secure Manage" -Source 'Install' -LogType 'CMTrace'
            $StatusMessageQuery = New-CMStatusMessageQuery -Name "OSCC Secure Manage actions triggered" -Expression "select SMS_StatusMessage.*, SMS_StatMsgInsStrings.*, SMS_StatMsgAttributes.* from  SMS_StatusMessage left join SMS_StatMsgInsStrings on SMS_StatMsgInsStrings.RecordID = SMS_StatusMessage.RecordID left join SMS_StatMsgAttributes on SMS_StatMsgAttributes.RecordID = SMS_StatusMessage.RecordID where SMS_StatMsgAttributes.AttributeID = 400 and SMS_StatMsgAttributes.AttributeValue = 'OSCCPWH'"
            Write-Log -Message "Created status message query for OSCC Secure Manage" -Source 'Install' -LogType 'CMTrace'
        }
        elseif ($forceupgrade)
        {
            Write-Log -Message "status message query for OSCC Secure Manage already exists" -Source 'Install' -LogType 'CMTrace'
            Write-Log -Message "Removing status message query" -Source 'Install' -LogType 'CMTrace'
            Remove-CMStatusMessageQuery -Name "OSCC Secure Manage actions triggered" -Force 
            Write-Log -Message "Recreating status message query for OSCC Secure Manage" -Source 'Install' -LogType 'CMTrace'
            $StatusMessageQuery = New-CMStatusMessageQuery -Name "OSCC Secure Manage actions triggered" -Expression "select SMS_StatusMessage.*, SMS_StatMsgInsStrings.*, SMS_StatMsgAttributes.* from  SMS_StatusMessage left join SMS_StatMsgInsStrings on SMS_StatMsgInsStrings.RecordID = SMS_StatusMessage.RecordID left join SMS_StatMsgAttributes on SMS_StatMsgAttributes.RecordID = SMS_StatusMessage.RecordID where SMS_StatMsgAttributes.AttributeID = 400 and SMS_StatMsgAttributes.AttributeValue = 'OSCCPWH'"
            Write-Log -Message "Created status message query for OSCC Secure Manage" -Source 'Install' -LogType 'CMTrace'

        }
        else
        {
             Write-Log -Message "status message query for OSCC Secure Manage already exists, forceupgrade not set, no action needed" -Source 'Install' -LogType 'CMTrace'
		}
#endregion		
#region configure PSremoting trusted hosts
        Write-Log -Message "Allowing adminui to connect to hosts using administrator account" -Source 'Install' -LogType 'CMTrace'
		set-item wsman:\localhost\Client\TrustedHosts -value $TrustedHostsValue -Force
#endregion

#region initial creation of secure manage tasksequence step with dummy package id
        Write-Log -Message "Testing if tasksequence action for OSCC Secure Manage already exists" -Source 'Install' -LogType 'CMTrace'
        if ((Get-CimClass -ErrorAction SilentlyContinue -Namespace root\sms\site_$sitecode -ClassName SMS_Tasksequence_SetLocalAdminPW).count -eq 0)
        {
            Write-Log -Message "Adding tasksequence step with Dummy package ID to allow tasksequence import."
			Write-Log -Messag "Compiling tasksequence action for setting the local admin password"
            Mofcomp -N:root\SMS\Site_$Sitecode "$env:SMS_LOG_PATH\..\TSSetLocalAdminPW.mof"
        }
        else
        {
            Write-Log -Message "Tasksequence action for OSCC Secure Manage already exists" -Source 'Install' -LogType 'CMTrace'        
		}
#end region		
#region import tasksequence		
		Write-Log -Message "Testing if sample tasksequence exists." -Source 'Install' -LogType 'CmTrace'
		if ((Get-CMTaskSequence -Name 'Secure Manage - Set random administrator password').count -eq 0)
		{
			Write-Log -Message 'Sample tasksequence does not exist, importing it.'
			Import-CMTaskSequence -Path "$packagepath\tasksequencesources\Secure manage exported tasksequence.zip"

		}
		else
        {
            Write-Log -Message "Sample tasksequence for OSCC Secure Manage already exists" -Source 'Install' -LogType 'CMTrace'        
		}
#endregion	

#region modify tasksequence step to have secure manage package preset
		$SecuremanagepackageID = (get-cmpackage -Name 'OSCC - Secure Manage').packageid
		(Get-Content "$env:SMS_LOG_PATH\..\TSSetLocalAdminPW.mof").Replace('Dummy',$SecuremanagepackageID) | Set-Content "$env:SMS_LOG_PATH\..\TSSetLocalAdminPW.mof"-Force
		Mofcomp -N:root\SMS\Site_$Sitecode "$env:SMS_LOG_PATH\..\TSSetLocalAdminPW.mof"
#endregion

		Remove-CMTaskSequenceStep -ActionClassName 'SMS_TaskSequence_InstallApplicationAction' -TaskSequenceName 'Secure Manage - Set random administrator password' -StepName 'Install Application dummy' -force


        if ($DistributeToDPGroup)
        {
            Start-CMContentDistribution -PackageId $PwToolPackage.PackageID -DistributionPointGroupName $DPGroupName
		}


		try {
			Write-Log -Messag "Trying to create Secure Manage Collection."
			New-CMDeviceCollection -LimitingCollectionId SMsDM003 -Name 'Secure Manage - Password reset targets' -RefreshType Manual -Comment 'Machines that havent reset the admin password in 7 days'
			Add-CMDeviceCollectionQueryMembershipRule -CollectionName 'Secure Manage - Password reset targets' -RuleName 'Secure Manage - Machine that havent reset the administrator account in 7 days' -QueryExpression 'select SMS_R_SYSTEM.ResourceID,SMS_R_SYSTEM.ResourceType,SMS_R_SYSTEM.Name,SMS_R_SYSTEM.SMSUniqueIdentifier,SMS_R_SYSTEM.ResourceDomainORWorkgroup,SMS_R_SYSTEM.Client from SMS_R_System where SMS_R_System.ResourceId not in (select SMS_R_SYSTEM.ResourceID from SMS_R_System   inner join SMS_G_System_SECUREMANAGESTATUS on SMS_G_System_SECUREMANAGESTATUS.ResourceId = SMS_R_System.ResourceId   WHERE (DateDiff(day, LastSuccessfulAttempt,GetDate()) < 7))'
		}
		catch {
			Write-Log -Messag "Failed to create Secure Manage Collection."
		}

		$ScriptFiles = Get-ChildItem Microsoft.PowerShell.Core\FileSystem::"$DirSupportFiles\Scriptsources" -Filter *.ps1
		foreach ($scriptFile in $ScriptFiles)
		{
			try
			{
				new-cmscript -ScriptFile $scriptfile.FullName -ScriptName $scriptFile.name.split('.')[0] -fast
			}
			catch
			{
				write-host 'error'
			}
		}
		try
		{
		$SecuremanagepackagePath = (get-cmpackage -Name 'OSCC - Secure Manage').pkgsourcepath
		Copy-item -Path "Microsoft.PowerShell.Core\FileSystem::$DirSupportfiles\setlocaladminpw\license.*" -Destination Microsoft.PowerShell.Core\FileSystem::$SecuremanagepackagePath -force
		unblock-file Microsoft.PowerShell.Core\FileSystem::$SecuremanagepackagePath -ErrorAction SilentlyContinue
		Write-Log -Message "Copying tasksequence action ui files & license for OSCC Secure Manage" -Source 'Install' -LogType 'CMTrace'
		}
		catch {Write-Host 'Failed to copy license'}

		Try
		{
		$dtxml = [xml]((Get-CMDeploymentType -ApplicationName 'Secure Manage AdminUI Extension').sdmpackagexml)
		$securemanageapplicationPath = $dtxml.AppMgmtDigest.DeploymentType.Installer.Contents.Content.Location
		Copy-item -Path "Microsoft.PowerShell.Core\FileSystem::$DirSupportfiles\getlocaladminpw\license.*" -Destination Microsoft.PowerShell.Core\FileSystem::$securemanageapplicationPath -force
		unblock-file Microsoft.PowerShell.Core\FileSystem::$securemanageapplicationPath -ErrorAction SilentlyContinue
		}
		catch
		{
		write-host "Failed to copy file to $securemanageapplicationPath"
		}
		
		##*===============================================
		##* POST-INSTALLATION
		##*===============================================
		[string]$installPhase = 'Post-Installation'
		
		## <Perform Post-Installation tasks here>
		## Writes unique file in ProgramData folder
		Write-Log -Message "Create and Write SWIDTag in ProgramData Folder" -Source 'Install' -LogType 'CMTrace'
		Write-SWIDTag -CreatorRegid $appVendorSWIDTAGRegID -EntitlementRequired $TRUE
		if ((get-CimClass -ClassName "sms_client" -Namespace root\ccm -ErrorAction SilentlyContinue).count -gt 0)
        {Invoke-SCCMTask 'HardwareInventory'}
        else
        {
    		Write-Log -Message "No SCCM Client WMI namespace found, not triggering hardware inventory" -Source 'Install' -LogType 'CMTrace'
        }
        Pop-Location
		
		## Display a message at the end of the install
		If (-not $useDefaultMsi) 
        { 
            #Show-InstallationPrompt -Message 'You can customize text to appear at the end of an install or remove it completely for unattended installations.' -ButtonRightText 'OK' -Icon Information -NoWait 
        }
	}
	ElseIf ($deploymentType -ieq 'Uninstall')
	{
		##*===============================================
		##* PRE-UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Pre-Uninstallation'
		
		## Show Welcome Message, close Internet Explorer with a 60 second countdown before automatically closing
		#Show-InstallationWelcome -CloseApps 'iexplore' -CloseAppsCountdown 60
		
		## Show Progress Message (with the default message)
		Show-InstallationProgress
		
		## <Perform Pre-Uninstallation tasks here>
		
		
		##*===============================================
		##* UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Uninstallation'
		
		## Handle Zero-Config MSI Uninstallations
		If ($useDefaultMsi) {
			[hashtable]$ExecuteDefaultMSISplat =  @{ Action = 'Uninstall'; Path = $defaultMsiFile }; If ($defaultMstFile) { $ExecuteDefaultMSISplat.Add('Transform', $defaultMstFile) }
			Execute-MSI @ExecuteDefaultMSISplat
		}
		
		# <Perform Uninstallation tasks here>
        Push-Location
        Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1"
        $Sitecode = (Get-PSDrive -PSProvider CMSite).name
        Set-Location ($Sitecode + ":")
        #Write-Log -Messag "Removing tasksequence action for setting the local admin password"
        #Remove-WmiObject -Class "SMS_Tasksequence_SetLocalAdminPW" -Namespace "root\sms\site_$sitecode"
        #Write-Log -Messag "Removed tasksequence action for setting the local admin password"
        if ((Get-CMPackage -Name "OSCC - Secure Manage").count -ne 0)
        {
            Write-Log -Message "Removing OSCC - Secure Manage Package" -Source 'Install' -LogType 'CMTrace'
            Remove-CMPackage -name 'OSCC - Secure Manage' -force
            Write-Log -Message "Removed OSCC - Secure Manage Package" -Source 'Install' -LogType 'CMTrace'
        }
        if ((Get-CMStatusMessageQuery -name 'OSCC Secure Manage actions triggered').count -ne 0)
        {
            Write-Log -Message "Removing OSCC Secure Manage actions triggered status message query" -Source 'Install' -LogType 'CMTrace'
            Remove-CMStatusMessageQuery -Name "OSCC Secure Manage actions triggered" -Force 
            Write-Log -Message "Removed OSCC Secure Manage actions triggered status message query" -Source 'Install' -LogType 'CMTrace'
        }
		Pop-Location
			
		##*===============================================
		##* POST-UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Post-Uninstallation'
		
		## <Perform Post-Uninstallation tasks here>
		## Removes unique file from ProgramData folder
		Write-Log -Message "Remove SWIDTAG File" -Source 'UnInstall' -LogType 'CMTrace'
                $tag = $env:ProgramData + '\' + $appVendorSWIDTAGRegID + '\' + $appVendorSWIDTAGRegID + '_' + $appName_WithSpace.Replace(' ','_') + '_' + $AppVersion + '_' + $AppArch +'.swidtag'
		Remove-File -Path $Tag
		        if ((get-CimClass -ClassName "sms_client" -Namespace root\ccm -ErrorAction SilentlyContinue).count -gt 0)
        {Invoke-SCCMTask 'HardwareInventory'}
        else
        {
    		Write-Log -Message "No SCCM Client WMI namespace found, not triggering hardware inventory" -Source 'Install' -LogType 'CMTrace'
        }
		
	}
	
	##*===============================================
	##* END SCRIPT BODY
	##*===============================================
	
	## Call the Exit-Script function to perform final cleanup operations
	Exit-Script -ExitCode $mainExitCode
}
Catch {
	[int32]$mainExitCode = 60001
	[string]$mainErrorMessage = "$(Resolve-Error)"
	Write-Log -Message $mainErrorMessage -Severity 3 -Source $deployAppScriptFriendlyName
	Show-DialogBox -Text $mainErrorMessage -Icon 'Stop'
	Exit-Script -ExitCode $mainExitCode
}

# SIG # Begin signature block
# MIIcdgYJKoZIhvcNAQcCoIIcZzCCHGMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD9Z9MlthsdGaw+
# R1YgRqq79J9lN51aQR9x6Sj97f6F5KCCF4AwggUJMIID8aADAgECAhANuwjc1awR
# STlYhzG60ROyMA0GCSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNV
# BAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcN
# MTcwOTE4MDAwMDAwWhcNMTkwMzA4MTIwMDAwWjBGMQswCQYDVQQGEwJCRTEPMA0G
# A1UEBxMGSGVyZW50MRIwEAYDVQQKEwlPU0NDIEJWQkExEjAQBgNVBAMTCU9TQ0Mg
# QlZCQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMeyYUwgipNp7rRm
# tBS3fcYqTGCvCqee7Dj9Weh5bgx/u6vIZna9Bp/zf5AvtGfIxHOXI0XnrzhPyC5/
# ZwzKdm0sPBb54dv8oIBTLRzuNJhfzwslVf4TvrJlVKZOkRisdnhGMw0kbIcXkaZb
# OpC0bcq43cwWZIr4NR20W39TiauezOQHMtRFxXLrM3mmn4UnCjpYT2XvsWbgtaIi
# tjowbPi1GbxxlbtKmIFYR6GQiQrA7rOMuo2pt2dJQ//tUM7d4/orUIm/RkDkI6f/
# iY6rB385JHXuqi4dW1y3gam2EVT++ni5H+yZ5Kqg7aEAXSsvHng9Jsw2ADr+p6E3
# DM+3CU0CAwEAAaOCAcUwggHBMB8GA1UdIwQYMBaAFFrEuXsqCqOl6nEDwGD5LfZl
# dQ5YMB0GA1UdDgQWBBRj1Tmj8IeGT5/pbLcDkFt8YdN6SzAOBgNVHQ8BAf8EBAMC
# B4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwdwYDVR0fBHAwbjA1oDOgMYYvaHR0cDov
# L2NybDMuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC1jcy1nMS5jcmwwNaAzoDGG
# L2h0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQtY3MtZzEuY3Js
# MEwGA1UdIARFMEMwNwYJYIZIAYb9bAMBMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8v
# d3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCAYGZ4EMAQQBMIGEBggrBgEFBQcBAQR4MHYw
# JAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBOBggrBgEFBQcw
# AoZCaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0U0hBMkFzc3Vy
# ZWRJRENvZGVTaWduaW5nQ0EuY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQEL
# BQADggEBAGYRcucefTNQbnJwBdy/82ouRUL8xGd8RwY1gabL0UI8qEr/xz387dJn
# +RVPOdvkpGFLwhOT1ADeOBrJciAdIpabE/OwWYwWsdmisMACzVCNrqOA+FfIVCwf
# /OTMa6XWI0/TRkpjNhPDTXcML8pp3pKSDTglWSXjAgyjfWEBq588eFuAaIZHmbyj
# 9Rom8ezaQ6DXIurRRT/uDvugIJ6r7ZRprT3/6oQBBLVybWYKTlsFckqsWXSD6TTZ
# QrDca0JS9HAAWsKAc2t0RKyFizuSjv3TuVSFNTJGb5R52USyoRsV8qtm6oHz9w7r
# baKI8WvFZdr5bvI0DQqco3WbaMcZSPswggUwMIIEGKADAgECAhAECRgbX9W7ZnVT
# Q7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxE
# aWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMT
# G0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBaFw0y
# ODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/lqJ3b
# Mtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fTeyOU
# 5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqHCN8M
# 9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+bMt+
# dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLoLFH3
# c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIByTAS
# BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggr
# BgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHoweDA6
# oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElE
# Um9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwAAgQw
# KjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAKBghg
# hkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0jBBgw
# FoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7sDVok
# s/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGSdQ9R
# tG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6r7VR
# wo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo+MUS
# aJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qzsIzV
# 6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHqaGxE
# MrJmoecYpJpkUe8wggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0GCSqG
# SIb3DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFz
# c3VyZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBaMEcx
# CzAJBgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGlnaUNl
# cnQgVGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLjntVa
# Y1sCSVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0ZLZQ
# t/USs3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafeTl/i
# qLYtWQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+z+yM
# DDZbesF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlXmVYw
# k/PJYczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB/wQE
# AwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYD
# VR0gBIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxodHRw
# czovL3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBB
# AG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBh
# AHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBj
# AGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABT
# ACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABB
# AGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBh
# AGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBh
# AHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAu
# MAsGCWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cCzTAd
# BgNVHQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDagNIYy
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5j
# cmwwOKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3Vy
# ZWRJRENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDov
# L29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5k
# aWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG9w0B
# AQUFAAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakbvFoW
# OQCd42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZBWs1
# kBCge5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/jbRcT
# Bu7kA7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenYk+VV
# FvC7Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOSK2vC
# UcIKSK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBs0wggW1oAMCAQICEAb9+QOWA63q
# AArrPye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoT
# DERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UE
# AxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAwMFoX
# DTIxMTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
# IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNl
# cnQgQXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEA6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+etSQV
# wpi5tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cxSIB8
# HqIPkg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0PdAug7
# Pe2xQaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLOBq6t
# hG9IhJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4aH63
# 1XcKJ1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQDAgGG
# MDsGA1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsGAQUF
# BwMEBggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAABBDCC
# AaQwOgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1jcHMt
# cmVwb3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBz
# AGUAIABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBv
# AG4AcwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAg
# AHQAaABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAg
# AHQAaABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBt
# AGUAbgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0
# AHkAIABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABo
# AGUAcgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9
# bAMVMBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUF
# BzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6
# Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5j
# cnQwgYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0LmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0OBBYE
# FBUAEisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6en
# IZ3zbcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukxR6tW
# XHvVDQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW0eu7
# NoR3zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz5Js5
# p8T1zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj++wc4
# Tw3GXZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9fAqg
# 7iwIVYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYIETDCC
# BEgCAQEwgYYwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZ
# MBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hB
# MiBBc3N1cmVkIElEIENvZGUgU2lnbmluZyBDQQIQDbsI3NWsEUk5WIcxutETsjAN
# BglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqG
# SIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3
# AgEVMC8GCSqGSIb3DQEJBDEiBCAf0DYluENiP2kZij1c/IzvpYy5dFKzPYX9w/PC
# a1xb6DANBgkqhkiG9w0BAQEFAASCAQCwlIkv1eDreyyAeNbN5vclyJQPtH1WHqQ9
# D0gOeUJMjbjCpNndflU/+o004A7WrfihiS/QE9bKWcifYRr3IIlbnq0H8yJkBsUW
# io80gLWutnuagGzhuBm5nC82qoHgH4LkwBSvFMFuP8h0IqhFttvtkmhHmLEMj4Qa
# AuqMy9qJugrLn0NaOuyjJvfcPA22ATaAXfaLP1n5iYqd2GMJj1lzZrvZFKciaq6V
# RkuNSZJF9a8B0g8oXgu4r7Ov55SmmSMJzKpuncnJlv6FoR5jZ1mk+WMiCdcCVGfT
# Or2hJOHSC23A+YZLa7EUPlz7BKtm4mEHYeZEAWiupJ170rYjgx7poYICDzCCAgsG
# CSqGSIb3DQEJBjGCAfwwggH4AgEBMHYwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoT
# DERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UE
# AxMYRGlnaUNlcnQgQXNzdXJlZCBJRCBDQS0xAhADAZoCOv9YsWvW1ermF/BmMAkG
# BSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJ
# BTEPFw0xODA3MTIxMjUxNDVaMCMGCSqGSIb3DQEJBDEWBBQwGLavs7VB+Wo3DzWi
# En9BaA0hIzANBgkqhkiG9w0BAQEFAASCAQBMK6kDgqkVfJbmPhKFXMS7r5FxBEEg
# 1RuN3p4xTSabTzqP/IrzXiT5lJs2x/kZYlmFoayICEYL10JShvdWucbEgyW4wmsm
# 2/Ja/BKaxtyCtAx5nKj7eyPG4PqaqO6oYSsYO6WKpaIPKExjB2SQree/YszhqR8N
# An1f2ZcRJaPBmpU8xFbjmlpZ/I3Eg98AOD4wwYqkwlCyud0DfJGu8UXR7yPtlFfB
# Ai9/0+RjcyZCcmUuE3ILPps39YiO/rC791eC9q5q60TahiOicJJdq/qCd1gDxvDk
# AG0DxkaNqrDmSJzD+GHSwQmN8Wdg4lubz51MCX16NWRCqPge6mOQ8N4D
# SIG # End signature block
